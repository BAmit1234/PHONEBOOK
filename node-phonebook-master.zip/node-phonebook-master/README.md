node-phonebook
==============

Simple phonebook example using node.js, express and redis
